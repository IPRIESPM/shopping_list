import React from 'react';

function ProductDetailPage() {
  return <div>ProductDetailPage</div>;
}

export default ProductDetailPage;
